<?php

namespace App\Http\Controllers;

use App\CmorghTeamUser;
use Illuminate\Http\Request;

class CmorghTeamUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CmorghTeamUser  $cmorghTeamUser
     * @return \Illuminate\Http\Response
     */
    public function show(CmorghTeamUser $cmorghTeamUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CmorghTeamUser  $cmorghTeamUser
     * @return \Illuminate\Http\Response
     */
    public function edit(CmorghTeamUser $cmorghTeamUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CmorghTeamUser  $cmorghTeamUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CmorghTeamUser $cmorghTeamUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CmorghTeamUser  $cmorghTeamUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(CmorghTeamUser $cmorghTeamUser)
    {
        //
    }
}
