<?php

namespace App\Http\Controllers;

use App\HomaUpload;
use Illuminate\Http\Request;

class HomaUploadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\HomaUpload  $homaUpload
     * @return \Illuminate\Http\Response
     */
    public function show(HomaUpload $homaUpload)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\HomaUpload  $homaUpload
     * @return \Illuminate\Http\Response
     */
    public function edit(HomaUpload $homaUpload)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\HomaUpload  $homaUpload
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, HomaUpload $homaUpload)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\HomaUpload  $homaUpload
     * @return \Illuminate\Http\Response
     */
    public function destroy(HomaUpload $homaUpload)
    {
        //
    }
}
